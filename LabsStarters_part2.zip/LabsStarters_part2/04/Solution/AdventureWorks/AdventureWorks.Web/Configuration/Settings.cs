﻿namespace AdventureWorks.Web
{
    public class Settings
    {
        public string BlobContainerUrl { get; set; }
    }
}