﻿using Azure;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

using System;
using System.Text;
using System.Threading.Tasks;

namespace MessageProcessor
{
    class Program
    {
        private const string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=asyncqstore;AccountKey=Z3OrpSGMRwog27US8ae+BGkTSsxp6FojvghmEMfzJjX3Ixk7ea3wwF3ODk9AYhyXaKg/N1tTILT3uSa1Ow4dbw==;EndpointSuffix=core.windows.net";
        private const string queueName = "messagequeue";
         public static async Task Main(string[] args)
         {
            QueueClient client = new QueueClient(storageConnectionString, queueName);
            if (null != await client.CreateIfNotExistsAsync())
            {
                Console.WriteLine("The queue was created.");
            }
            await client.CreateAsync();
                Console.WriteLine($"---Account Metadata---");
                Console.WriteLine($"Account Uri:\t{client.Uri}");
                Console.WriteLine($"---Existing Messages---");
                int batchSize = 10; //max 32. If fewere are visible they are returned
                TimeSpan visibilityTimeout = TimeSpan.FromSeconds(7.5d);
                await client.ReceiveMessagesAsync(batchSize, visibilityTimeout);
                
                Response<QueueMessage[]> messages = await client.ReceiveMessagesAsync(batchSize, visibilityTimeout);
            int counter = 0;
            //read the messages
            foreach(QueueMessage message in messages?.Value)
                {
                     if (message.DequeueCount > 0)
                    {
                        counter++;
                        string strBase64 = string.Join("",message.Body);
                        string strMessage  = Base64Decode(strBase64);
                            
                            Console.WriteLine($"[{message.MessageId}]\t{strMessage}\t{counter}");
                    
                            await client.DeleteMessageAsync(message.MessageId, message.PopReceipt);
                    }
            }
                
            
                Console.WriteLine($"---New Messages---");
            /*
            for (int i = 0; i < 20; i++)
            {
                
                string greeting = "Hello Queued Storage!" + DateTime.Now.ToString();
                await client.SendMessageAsync(Convert.ToBase64String(Encoding.UTF8.GetBytes(greeting)));

                Console.WriteLine($"Sent Message:\t{greeting}");
            }
        */          
            
            
            


        }
         private static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

    }
}
